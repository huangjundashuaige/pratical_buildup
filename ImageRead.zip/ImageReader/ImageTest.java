import com.sun.org.apache.regexp.internal.RETest;
import com.sun.org.apache.xpath.internal.functions.FuncSubstringBefore;
import org.junit.Test;
import org.junit.Before;

import java.awt.Graphics2D;  
import java.awt.Image;  
import java.awt.Toolkit;  
import java.awt.image.BufferedImage;  
import java.awt.image.ImageProducer;  
import java.awt.image.MemoryImageSource;  
import java.io.File;  
import java.io.FileInputStream;  
import java.io.FileNotFoundException;
import java.io.FileOutputStream;  
import java.io.IOException;
import javax.imageio.ImageIO; 
import imagereader.IImageIO; 
import javax.sound.midi.SysexMessage;
import sun.java2d.pipe.BufferedContext;
public class ImageTest
{
    public Image origin;
    public ImplementImageIO myImageIO;
    public ImplementImageProcessor myImageProcessor;
    @Before
    public void ready()
    {
        myImageIO = new ImplementImageIO();
        myImageProcessor = new ImplementImageProcessor();
        origin = ImageIO.read(new File("./1.bmp"));

    }
    @Test
    public void readTest()
    {
        Image myReadImage = myImageIO.myRead("./1.bmp");
        assertEquals(true,compareImage(myReadImage,origin));
    }
    private boolean compareImage(Image i1,Image i2)
    {
        BufferedImage buff1 = new BufferedImage(i1.getWidth(null),i1.getHeight(null), BufferedImage.TYPE_INT_RGB);
        BufferedImage buff2 = new BufferedImage(i2.getWidth(null),i2.getHeight(null), BufferedImage.TYPE_INT_RGB);
        if(i1.getHeight(null)!=i2.getHeight(null))
        {
            return false;
        }
        if(i1.getWidth(null)!=i2.getWidth(null))
        {
            return false;
        }
        for(int i=0;i<i1.getWidth(null);i++)
        {
            for(int j=0;j<i2.getHeight(null);i++)
            {
                if(buff1.getRGB(i,j)!=buff2.getRGB(i,j))
                {
                    return false;
                }
            }
        }
        return true;
    }
    @Test
    public void redTest()
    {
        Image myReadImage = myImageIO.myRead("bmptest/goal/1_red_goal.bmp");
        assertEquals(true,compareImage(myReadImage,myImageProcessor.showChanelR(origin));
    }
    @Test
    public void blueTest()
    {
        Image myReadImage = myImageIO.myRead("bmptest/goal/1_blue_goal.bmp");
        assertEquals(true,compareImage(myReadImage,myImageProcessor.showChanelB(origin));
    }
    @Test
    public void greenTest()
    {
        Image myReadImage = myImageIO.myRead("bmptest/goal/1_green_goal.bmp");
        assertEquals(true,compareImage(myReadImage,myImageProcessor.showChanelG(origin));
    }
    @Test
    public void grayTest()
    {
        Image myReadImage = myImageIO.myRead("bmptest/goal/1_gray_goal.bmp");
        assertEquals(true,compareImage(myReadImage,myImageProcessor.showGray(origin));
    }

}