import java.awt.image.RGBImageFilter; 

public class ColorFilter extends RGBImageFilter{  
    private String filterMode;  
  
    public ColorFilter(String mode)
    {  
        this.filterMode = mode;  
        canFilterIndexColorModel = true;  
    }  
      
    public int filterRGB(int x, int y, int rgb)
    {   
        if(this.filterMode=="red")
        {  
            return ( rgb & 0xffff0000 );  
        }
        else if(this.filterMode=="green")
        {  
            return ( rgb & 0xff00ff00 );  
        }
        else if(this.filterMode=="blue")
        {  
            return ( rgb & 0xff0000ff );  
        }
        else if(this.filterMode=="grey")
        {  
            int g = (int)( ((rgb & 0x00ff0000) >> 16)*0.299 + ((rgb & 0x0000ff00) >> 8 )*0.587  
                    + ((rgb & 0x000000ff))*0.114 );  
            return 0xff000000 + (g << 16) + (g << 8) + g;  
        }  
        return -1;
    }  
}  