import javax.sound.midi.SysexMessage;

public class MainClass
{
    public static void main(String args[])
    {
        ImplementImageIO imageIO = new ImplementImageIO();
        try {
            imageIO.myWrite(imageIO.myRead("./1.bmp"),"./1_test.bmp");
        }
        catch (Exception err) {
            //System.out.println(err.${getMessage()});
            System.out.println("err");
        }

    }
}