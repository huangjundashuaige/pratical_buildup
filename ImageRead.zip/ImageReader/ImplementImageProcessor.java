import imagereader.IImageProcessor;  
import java.awt.Image;  
import java.awt.Toolkit;  
import java.awt.image.FilteredImageSource;  
 
  
public class ImplementImageProcessor implements IImageProcessor{  
      
    public Image showChanelR(Image sourceImage){  
        ColorFilter redFilter = new ColorFilter("red");  
        Toolkit toolKit = Toolkit.getDefaultToolkit();  
        Image img = toolKit.createImage(new FilteredImageSource(sourceImage.getSource(), redFilter));  
        return img;  
    }  
      
    public Image showChanelG(Image sourceImage){  
        ColorFilter greenFilter = new ColorFilter("green");  
        Toolkit toolKit = Toolkit.getDefaultToolkit();  
        Image img = toolKit.createImage(new FilteredImageSource(sourceImage.getSource(), greenFilter));  
        return img;  
    }  
      
    public Image showChanelB(Image sourceImage){  
        ColorFilter blueFilter = new ColorFilter("blue");  
        Toolkit toolKit = Toolkit.getDefaultToolkit();  
        Image img = toolKit.createImage(new FilteredImageSource(sourceImage.getSource(), blueFilter));  
        return img;  
    }  
      
    public Image showGray(Image sourceImage){  
        ColorFilter grayFilter = new ColorFilter("grey");  
        Toolkit toolKit = Toolkit.getDefaultToolkit();  
        Image img = toolKit.createImage(new FilteredImageSource(sourceImage.getSource(), grayFilter));  
        return img;  
    }  
  
}  

