// ImagaReaderRunner.java
import imagereader.Runner;  
import imagereader.IImageIO;
import imagereader.IImageProcessor;
public class ImageReadeRunner {  
  
    public static void main(String args[]){  
          
        IImageIO myImageIO = new ImplementImageIO();  
          
        IImageProcessor myImageProcessor = new ImplementImageProcessor();  
          
        Runner.run(myImageIO, myImageProcessor);  
    }  
}  