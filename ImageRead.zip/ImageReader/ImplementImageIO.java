import java.awt.Graphics2D;  
import java.awt.Image;  
import java.awt.Toolkit;  
import java.awt.image.BufferedImage;  
import java.awt.image.ImageProducer;  
import java.awt.image.MemoryImageSource;  
import java.io.File;  
import java.io.FileInputStream;  
import java.io.FileNotFoundException;
import java.io.FileOutputStream;  
import java.io.IOException;
import javax.imageio.ImageIO; 
import imagereader.IImageIO; 
import javax.sound.midi.SysexMessage;
/*
这部分是识别信息，典型的应用程序会首先普通读取这部分数据以确保的确是位图文件并且没有损坏。

字节	属性
#0-1	保存位图文件的标识符，这两个字节的典型数据是BM
#2-5	使用一个dword保存位图文件大小
#6-9	是保留部分，留做以后的扩展使用,对实际的解码格式没有影响
#10-13	保存位图数据位置的地址偏移，也就是起始地址
2.2 位图信息

这部分告诉应用程序图像的详细信息，在屏幕上显示图像将会使用这些信息，它从文件的第15个字节开始。

字节	属性
#14-17	定义以下用来描述影像的区块（BitmapInfoHeader）的大小。它的值是：40 - Windows 3.2、95、NT、12 - OS/2 1.x、240 - OS/2 2.x
#18-21	保存位图宽度（以像素个数表示）
#22-25	保存位图高度（以像素个数表示）
#26-27	保存所用彩色位面的个数。不经常使用
#28-29	保存每个像素的位数，它是图像的颜色深度。常用值是1、4、8（灰阶）和24（彩色）
#30-33	定义所用的压缩算法。允许的值是0、1、2、3、4、5，见下表
#34-37	保存图像大小。这是原始 （:en:raw）位图数据的大小，不要与文件大小混淆。
#38-41	保存图像水平方向分辨率
#42-45	保存图像竖值方向分辨率
#46-49	保存所用颜色数目
#50-53	保存所用重要颜色数目。当每个颜色都重要时这个值与颜色数目相等
压缩算法的值	定义
0	没有压缩（也用BI_RGB表示
1	行程长度编码 8位/像素（也用BI_RLE8表示）
2	行程长度编码4位/像素（也用BI_RLE4表示）
3	Bit field（也用BI_BITFIELDS表示）
4	JPEG图像（也用BI_JPEG表示）
5	PNG图像（也用BI_PNG表示）
*/

public class ImplementImageIO implements IImageIO 
{
    public int readPixelWithExtra(byte[] oriMap,int begin)
    {
        return (oriMap[begin]&0xff) | (oriMap[begin+1]&0xff)<<8 | (oriMap[begin+2]&0xff)<<16 | 0xff<<24;
    }
    public int readBin(byte[] list,int begin)
    {
        return (int)(list[begin]&0xff | (list[begin+1]&0xff)<<8 | (list[begin+2]&0xff)<<16 | (list[begin+3]&0xff)<<24);
    }
    public int[] read24Bmp(FileInputStream fs,int totalBmpByte,int rowBmpPixel,int colBmpPixel)
    {

        try {
                    
            int resMap[] = new int[rowBmpPixel*colBmpPixel];
            int spacePerRowPixel = totalBmpByte/(3*colBmpPixel) - rowBmpPixel;
            byte oriMap[] = new byte[totalBmpByte];
            fs.read(oriMap,0,totalBmpByte);
            //System.out.println(colBmpPixel+":2");
            int count=0;
            for(int i = colBmpPixel-1;i>=0;i--)
            {
                    for(int j=0;j<rowBmpPixel;j++)
                    {
                        resMap[i*rowBmpPixel+j] = readPixelWithExtra(oriMap,count);
                        count+=3;
                    }
                    count+=spacePerRowPixel*3;
            }
            return resMap;
        }
        catch (Exception err) {
            //System.out.println(err.getMessage());
            System.out.println("ioexception");
            return new int[0];
        }


    }
    public Image myRead(String filePath)//throws FileNotFoundException
    {
        Image img;
        try 
        {
            File file = new File(filePath); 
            FileInputStream fs = new FileInputStream(file);
            byte head[] = new byte[14];  
            byte info[] = new byte[40]; 
            fs.read(head, 0, 14);  
            fs.read(info, 0, 40); 
            int totalFileByte = readBin(head,2);
            int offset = readBin(head,10);
              
            //读取位图信息，保存位图大小，每一个像素为3个字节  
            int totalBmpByte = readBin(info,20);  
              
            //读取位图宽度,单位为像素  
            int rowBmpPixel = readBin(info,4); 
              
            //读取位图高度，单位为像素  
            int colBmpPixel = readBin(info,8);
            System.out.println(colBmpPixel);
            int typeBmp = (int)( (info[15]) << 8 | (info[14]) ); 
            System.out.println(typeBmp);
            int pixelArray[];
            if(typeBmp==24)
            {
                pixelArray=read24Bmp(fs,totalBmpByte,rowBmpPixel,colBmpPixel);
                //System.out.println("what");
            }
            else
            {
                pixelArray = new int[0];
            }
            img = Toolkit.getDefaultToolkit().createImage((ImageProducer) new MemoryImageSource(  
                rowBmpPixel, colBmpPixel, pixelArray, 0, rowBmpPixel));  
            //System.out.println(img.getHeight(null));
            //BufferedImage buffer = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
            //Graphics2D graph = buffer.createGraphics();
            //graph.drawImage(img, 0, 0, null);
            //graph.dispose();
            //System.out.println(img.getWidth(null));

            fs.close();  
            return img;
        }
        catch (Exception err) {
            System.out.println("read wrong");
        };
        return (Image)null;
    }
    public Image myWrite (Image image, String filepath)
    {
        try
        {
            File imgFile = new File(filepath);
            image.getWidth(null);
            image.getHeight(null);
            BufferedImage buffer = new BufferedImage(image.getWidth(null),image.getHeight(null), BufferedImage.TYPE_INT_RGB);
            //System.out.println("bmp err");
            Graphics2D graph = buffer.createGraphics();
            graph.drawImage(image, 0, 0, null);
            //graph.dispose();
            ImageIO.write(buffer, "bmp", imgFile );
        }
        catch(Exception e)
        {
            System.out.println("write wrong");
            return image;
        }
        return image;
    }
}