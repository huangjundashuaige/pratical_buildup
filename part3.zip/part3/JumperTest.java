import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;
import org.junit.Test;

import java.awt.*;

import static org.junit.Assert.*;

public class JumperTest {
  private Jumper jumper = new Jumper();
  private ActorWorld world = new ActorWorld();
  private Rock newRock = new Rock();

  @Test
  public void testAct() {
    world.add(new Location(2, 2), jumper);
    jumper.act();
    jumper.act();
    jumper.act();
    jumper.act();
    assertEquals(new Location(0, 4), jumper.getLocation());
  }
  /**
   * check the turn method is right or not.
   */
  @Test
  public void testTurn() {
    world.add(new Location(2, 2), jumper);
    jumper.turn();
    assertEquals(45, jumper.getDirection());
  }

  /**
   * check the move method is right or not.
   */
  @Test
  public void testMove() {
    world.add(new Location(2, 2), jumper);
    jumper.move();
    assertEquals(new Location(1, 2), jumper.getLocation());
  }

  /**
   * check the canMove method is right or not.
   */
  @Test
  public void testCanMove() {
    world.add(new Location(2, 2), jumper);
    world.add(new Location(1,2),new Rock());
    world.add(new Location(0, 2), newRock);
    assertEquals(false, jumper.canMove());
  }

}

