lalaland
command: java org.junit.runner.JUnitCore xx
	sonar-runner 在property的文件目录下可开启 
	cd $SONAR_HOME 
	junit 要把所有文件一起编译
	sonar要在有文件的地方

# study report
**Name:** 黄俊

**Class:**  软件工程教务二班

**Date:** 14.4.2018

-----

## learning vi/vim
its well known that seems all the hacker love vi or vim,not only for its light-weighted style and great compability of self-customize，but also for it is perfect for people have to remote to server which means you dont have gui or even have mouse to help you to page up/down.And if you using vi,it will become pretty easy for you to adjust your code a little bit and dont need to transfer your file back to your pc and transfer back.
1. multiple mode
  as its well known to us that vi has three mode,and 
  - they are command mode,you can easily manipulate you code(copy cut paste),and page up and down become very easy,most importantly you can even search certain word,which will greatly improve you coding effience.
- the other is insert mode,whose usage is very obivious according to its name.you can actucally key in you code.
- last line mode,whose usage is that you can save you current file or log out,because when you using terminal you cant actually switch between different program.	
2. powerfu shortcut key
	if you ask about what make vi so popular,i would say shortcut key helps a lot,those shortcut key imporve you effience not just a little bit.
3. many useful plug-in
	i believe when you first using vi,you probably will disapoint about his colorless gui.but its not a problem now,thanks to those opensource contributor,vi and vim have many plug-in which can not only dressing you editor but also provide extra good functionality.
<pre lang="python">
	import tensor as tf
</pre>

## learning java and how to play with jdk
1. deploying jdk and jre.Well at firts i often wonder how many people are actually get bored when do something like deploying jdk on his own computer and lose the opprtunity to get a chance to know java.indeed java is not like python which is way lighter than java,and you dont need an idea only a text-editor will do fine.as for java,when you download the jdk you have to make sure the jdk's location and the global enviorment was the most distribing thing to do,CLASSPATH JAVA_HOME,java indeed is not a rookie-friendly language.
2. as for learning java,i have to say i didnt learing oop very well,mainly because c and python and js maybe is not first design for oop,but java and c# is totally different,their first motivation to creat such language is to make it more suitable to oop. <br>
and its first design was code file is the class(object).each class access each other by the filename.and the design of simgle-inherit plus interface design are actually amazing which means the designer of java just limit us to the specify pattern design which disabled multi-inherit.<br>
and the other field of java's oop is its inherit tree are very good,every object was inherit from the prime OBJECT class,which is a gurantee for polymorphism.and also make sure every class could have most meaning by by its inherit tree.<br>
also abstract class is making the java's oop more meaningful,maybe different people have different thought about this thing,some programer believe less limit is good,what programer have to do is to prevent bug from happening,the potential dangerous of a program language cant be convineng for them ,as for security is less important at this way,so they probable not like the abstract design of java.as for other programer believe program language should provide security for them in case they making mistake and the compile will waring you is good,they will love java's design and also those type-safe language.as for me?of course i am the kind of guy whose code is very blowing and i dont like being caught to the rules of compile,happiness of myself should be the first thinf to concern.
## learning ant 
- auto compile and deploing by ant
	well,so of the most distribing of java or c this kind of langage is that although java's motto is code once running everywhere,but nowadays its really not gonna happen now.<br>
	facebook's react framework's learing once,code anywhere is more likely the future trend of programing language.the reason why java's will was over is that although using java virtual machine is good idea to get away with the assmbly of the soc or cpu,but there are still many difference between different platform,most obviously is the display device,so it means once you want tranplant you program from pc to phone,a lot changes need to make,some of them's workload might make you feel like code a compeletely new program.<br>
	but still even you move your code form one device to other same device,you still will have some problem like you cant simply transfer your class file,because even the enviorment of two device have some little difference which will make you program stop running in the other device.<br>
	the wise movement is that you can transfer your source code,which is suit for all devices.and you deploy them,which will make the code fits your jdk and your enviorment,that sounds very good,but still have some problem because what if your source file have like 1000 class and they all are at different directory.it will be painful for you to complile them.so there we are,we have the auto-deploy program for us to doing the deploying things free us from many boring dirty work.<br>
	as for how this amazing program work,i will give some example

```

	<project name="hello world" default="test" basedir=".">
	<description>
	this is a simple hello world program to test ant and junit plug-in
	</description>
	<property name="source" location="source"/>
	<property name="classes" location="."/>

	<target name="init">
	<mkdir dir="${classes}"/>
	</target>

	<target name="compile" depends="init" description="compile java file">
	<javac srcdir="${source}" destdir="${classes}"/>
	</target>

	<target name="run" depends="compile">
	<java classname="hello_world" fork="yes" dir="./classes">
	</java>
	</target>

	<target name="test" depends="run">
	<junit printsummary="true">
	<classpath>
	<pathelement location="/opt/resources/junit-4.9.jar"/>
	</classpath>
	<test name="test_hello_world"/>
	</junit>
	</target>
	</project> 

```
the main code is that which is the format of xml,which just like html is the mark language so you can place your order at the label + attribute.the label\<target> means a unique task and the depends means when you first want to do this task your should previously do the other work provided by the depends attribute.<br>
and the label inside the target is the specified task provided by ant,there have \<javac> which is the compile command and the \<java> label which is the excute command.and there are many other functionality supported by ant,like \<junit>.so it can free your from doing boring works.<br>
and most importly you can use * this kind of identifier to help deal with large quantities of target files.
## junit 
- ant junit auto test helloworld<br>
its well know that when you are dealing with a big project,a few iteration to your product is definately needed,but this leads a very distribing fact that coding is very fluent,but afterwards when you have to test your code which not only build other test cases.and after iteration,you wiil have to do it again.<br>
so is it other apporatch to make things easier?<br>
there do have,its the unit test,which means there will be extra class whose job is to test the main-logic code whenever you change a bit your current code.<br>
and when you runing you code,the test will be done automatically,of course you can also add the junit function into the ant code,and everything can be done automatically just be runing the single command ant.
- lets anaylise the code of junit
```
import static org.junit.Assert.*;
import org.junit.Test;
public class test_hello_world
{
String s=hello_world.output();
String s1="hello world!\n";
@Test
public void test()
{
System.out.println("expected: "+s1+"\n"+"actual: "+s);
assertEquals(s, s1);
}
}
```

as you can see,i import the library of junit.and by putting @Test candy before the function,it means when you runing the junit this function will be calling and show you some reult,and what the function do is that by accessing the target class and compare your expected result with the true result.
