import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Calculator extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/my_pane.fxml"));
        primaryStage.setTitle("Calculator");
        /*to set the title*/
        final double width=400;     
        /*easy to change*/
        final double height=200;    
        /*to change*/
        Scene scene = new Scene(root, width, height, Color.TRANSPARENT);
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
