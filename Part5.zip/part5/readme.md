# introduction of these projects
1. the first is the bouned grid made of linked list,which using arraylist of node as the row,and the linklist of node make up the col
2. the second is the bouned grid completed by the hashmap which can speed up the acess speed
3.  the third is using dynamic array to implement the unbouned grid which is space-saved plan for if the game need just a few space and this plan can beat the other implement for ubounged grid